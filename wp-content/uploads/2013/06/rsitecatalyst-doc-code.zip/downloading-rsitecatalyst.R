
#### Download RSiteCatalyst from GitHub
install.packages("devtools")
library(devtools)

install_github("RSiteCatalyst", "randyzwitch")
library(RSiteCatalyst)


#### Near future (hopefully), download from CRAN
install.packages("RSiteCatalyst")
