#QueueOvertime Report: Report where only breakdown/granularity can be time
#Report same as the Key Metrics report or an Event report

#Minimum amount of code - sum of pageviews during 3/1 - 3/14 period
#This call returns sum of all days because no granularity period specified
#2121 pageviews, just like SiteCatalyst report
pageviews_march_total <- 
QueueOvertime("keystonerandy", "2013-03-01", "2013-03-14", "pageviews")

#Same totals report, with more metrics
#2121 page views, 1623 visits, 1471 unique visitors, 1381 bounces
#Same as SiteCatalyst report
march_total_metrics <- 
QueueOvertime("keystonerandy", "2013-03-01", "2013-03-14", 
              c("pageviews", "visits", "cvisitorsmonthly", "bounces"))

#Same 4 metrics report, but now by day
march_daily_metrics <- 
QueueOvertime("keystonerandy", "2013-03-01", "2013-03-14", 
              c("pageviews", "visits", "cvisitorsmonthly", "bounces"), "day")

#Not run:  adding "Loyal_Visitors" segment to report
#Same 4 metrics report, but now by day
march_daily_metrics_loyal <- 
QueueOvertime("keystonerandy", "2013-03-01", "2013-03-14", 
              c("pageviews", "visits", "cvisitorsmonthly", "bounces"), "day",
              "Loyal_Visitors")

#Control Chart for Daily Visits
library(qcc)
calibration <- as.numeric(march_daily_metrics$visits[1:10])
future <- as.numeric(march_daily_metrics$visits[11:14])
qcc(calibration, newdata=future, type="xbar.one", 
    title="Control Chart - Visits \n randyzwitch.com")

