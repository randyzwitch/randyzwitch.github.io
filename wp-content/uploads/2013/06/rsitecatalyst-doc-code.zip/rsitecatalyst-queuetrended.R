#QueueTrended: single report suite, single metric, single elements
#Similar syntax to QueueRanked, except with dateGranularity argument

natsearch_daily <-  
QueueTrended("keystonerandy", "2013-02-01", "2013-03-18", "day", 
"pageviews", "searchenginenaturalkeyword", top="100000", startingWith= "1")


antiquebrowsers_day <-  
QueueTrended("keystonerandy", "2013-02-01", "2013-03-18", "day", 
"visits", "browser", selected = c("Microsoft Internet Explorer 7.0", 
                                  "Microsoft Internet Explorer 6.0",
                                  "Microsoft Internet Explorer 6.0 (AOL)",
                                  "AOL 9.0", 
                                  "Microsoft Internet Explorer 7.0 (AOL)",
                                  "Safari 3.1",
                                  "Google Chrome 4.0"))


#Plot antique browsers
library(ggplot2)
#Create date as POSIXct class
antiquebrowsers_day$date <- as.POSIXct(paste(antiquebrowsers_day$year, 
                            antiquebrowsers_day$month, antiquebrowsers_day$day, sep = "-"))
#Convert browser to factor
antiquebrowsers_day$browser <- as.factor(antiquebrowsers_day$browser)

qplot(date, visits, data= antiquebrowsers_day, group = browser,color=browser, 
      geom = c("point", "line"),
      main = "Antique Browser Visits Over Time")
