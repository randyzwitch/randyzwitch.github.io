#Call SCAuth function to set credentials before usage
SCAuth("rzwitch:keystone", "<shared_secret_goes_here>")

#Run GetTokenCount as a check that the credentials are working properly
GetTokenCount()