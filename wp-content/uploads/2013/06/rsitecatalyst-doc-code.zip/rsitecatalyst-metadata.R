#GetReportSuites to find out what Report Suites are available to your username
report_suites <- GetReportSuites()

# GetAvailableElements - Useful for understanding what breakdowns available
# for use in Reporting API
elements <- GetAvailableElements("keystonerandy")
elements <- GetAvailableElements(report_suites$rsid)

# GetAvailableMetrics - Useful for understanding what metrics available
# for use in Reporting API
metrics <- GetAvailableMetrics(c("keystonerandy"))
metrics <- GetAvailableMetrics(report_suites$rsid)

#GetEVars - pass a single argument or concatentated vector
eVars <- GetEVars(c("keystonejowanza", "keystonerandy", "keystonetraining"))
eVars <- GetEVars(report_suites$rsid)

#GetSegments - pass a single argument or concatentated vector
segments <- GetSegments(c("keystonerandy"))
segments <- GetSegments(report_suites$rsid)

#GetSuccessEvents - pass a single argument or concatentated vector
events <- GetSuccessEvents("keystonerandy")
events <- GetSuccessEvents(report_suites$rsid)

#GetTrafficVars - pass a single argument or concatentated vector
trafficvars <- GetTrafficVars(c("keystonejowanza"))
trafficvars <- GetTrafficVars(report_suites$rsid)