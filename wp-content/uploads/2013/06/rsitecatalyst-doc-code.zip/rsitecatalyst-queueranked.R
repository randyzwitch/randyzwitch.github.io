#QueueRanked - Pull a ranked report, either "Top" number of values or specific ones
#RSiteCatalyst currently doesn't support subrelations/correlations

#(Up to) Top 100,000 natural search keywords, starting with #1
top_searchkw <- 
QueueRanked("keystonerandy", "2013-02-01","2013-03-14", 
            c("visits", "pageviews", "cvisitorsmonthly"),
            "searchenginenaturalkeyword", top= "100000", startingWith= "1")


#Get just the elements you want from the ranked list, instead of "Top"
homepage_aboutpage <- 
QueueRanked("keystonerandy", "2013-02-01","2013-03-14", c("pageviews", "visits"),
            'page', selected = c("http://randyzwitch.com", "http://randyzwitch.com/about"))


#Create search term cluster using a dendrogram
library(tm)

# build a corpus
mydata.corpus <- Corpus(VectorSource(top_searchkw$"Natural Search Keyword"))

# make each letter lowercase
mydata.corpus <- tm_map(mydata.corpus, tolower) 

# remove punctuation 
mydata.corpus <- tm_map(mydata.corpus, removePunctuation)

# remove generic and custom stopwords
my_stopwords <- c(stopwords('english'))
mydata.corpus <- tm_map(mydata.corpus, removeWords, my_stopwords)

# build a term-document matrix
mydata.dtm <- TermDocumentMatrix(mydata.corpus)

# remove sparse terms to simplify the cluster plot
# Note: tweak the sparse parameter to determine the number of words.
# About 10-30 words is good.
# Closer to 1, more terms
mydata.dtm2 <- removeSparseTerms(mydata.dtm, sparse=0.98)

# convert the sparse term-document matrix to a standard data frame
mydata.df <- as.data.frame(inspect(mydata.dtm2))

mydata.df.scale <- scale(mydata.df)
d <- dist(mydata.df.scale, method = "euclidean") # distance matrix
fit <- hclust(d, method="ward")
plot(fit, main="Search Keywords", xlab= "Clusters") 


